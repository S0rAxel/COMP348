public interface Shape extends NamedObject
{
    public double getPerimeter();
    public double getArea();
}
